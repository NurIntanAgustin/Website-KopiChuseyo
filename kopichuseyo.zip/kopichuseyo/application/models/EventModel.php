<?php

Class EventModel extends CI_Model
{
    public $id_event;
    public $nama_event;
    public $tanggal_event;
    public $penyelenggara;
    public $tentang;
    public $cara_mendapatkan;
    public $gambar_event;

    public function get_all_data_event()
    {
        $query = "SELECT * from event";
        return $this->db->query($query)->result_array();
    }

    function events_get_list($where = null)
	{
		if ($where) {
			$this->db->where($where);
		}
		$q = $this->db->get('event');
		return $result = $q->num_rows() > 0 ? $q->result_array() : array();
	}
}
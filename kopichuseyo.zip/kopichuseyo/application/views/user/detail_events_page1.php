<div class="card">
<div class="card-header bg-white">
	<h1 class="h3 text-gray-800"><?= $title_page ?? $title ?></h1>
</div>
                    <div class="card-body">
                        <div div class="mt-3 text-center">
                        <img src="<?=base_url();?>assets/img/3.png" height="230" width="230"class="img-fluid rounded-start" alt="...">
                        </div>
                        <div class="mt-4 text-center">
                        <h5>VINCENZO CUPSLEEVE EVENT</h5>
                        </div>
                        <div class="mt-3">
                        <div class="card text-center">
                        <div class="card-header">
                            <ul class="nav nav-tabs card-header-tabs">
                            <li class="nav-item">
                                <a class="nav-link" aria-current="true" href="<?=base_url();?>user/detail_events_page">Tentang</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="true" href="<?=base_url();?>user/detail_events_page1">Cara Mendapatkan</a>
                            </li>
                            </ul>
                        </div>
                        <div class="card-body mt-3 text-left">
                        <ul>
                                <li>Lakukan pemesanan di Kopi Chuseyo selain air mineral</li>
                                <li>Tukarkan struk pemesanan kepada salah satu Admin kami yang ada di Stand</li>
                                <li>Lakukan pembayaran Rp 5000/bundling</li>
                            </ul>
                            <br></br>
                 
                        </div>
                        </div>
                        </div>
                    </div>
                    </div>
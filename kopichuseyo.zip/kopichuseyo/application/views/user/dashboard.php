<div class="card">
                    <img src="<?= base_url();?>assets/img/kopcus1.jpg" class="card-img-top" alt="header">
                    
                    <div class="card-body">
                        <div class="mt-5">
                            <h4><b>EVENTS AND PROMOS</b></h4>
                        </div>
                    <div class="row mt-3">
                    <div class="col-sm-3">
                        <div class="card">
                        <div class="card-body">
                            <div class="card-img" style="margin: auto;">
                                <img src="<?=base_url();?>assets/img/3.png" height="230" width="230">
                            </div>
                            <div class="mt-3">
                            <h6 class="text-center"><a href="#">VINCENZO CUPSLEEVE EVENT</a></h6>
                            </div>
                        </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card">
                        <div class="card-body">
                            <div class="card-img" style="margin: auto;">
                                <img src="<?=base_url();?>assets/img/1.jpg" height="230" width="230">
                            </div>
                            <div class="mt-3">
                            <h6 class="text-center"><a href="#">K-FOOD OF THE WEEK</a></h6>
                            </div>
                        </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card">
                        <div class="card-body">
                            <div class="card-img" style="margin: auto;">
                                <img src="<?=base_url();?>assets/img/2.jpg" height="230" width="230">
                            </div>
                            <div class="mt-3">
                            <h6 class="text-center"><a href="#">NCT ANNIVERSARY EVENT</a></h6>
                            </div>
                        </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card">
                        <div class="card-body">
                        <div class="card-img" style="margin: auto;">
                                <img src="<?=base_url();?>assets/img/4.png" height="230" width="230">
                            </div>
                            <div class="mt-3">
                            <h6 class="text-center"><a href="#">HWANG INYOUP DAY EVENT</a></h6>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                        <div class="mt-5">
                            <h4><b>MUST TRY MENUS</b></h4>
                        </div>
                    <div class="row mt-3">
                    <div class="col-sm-3">
                        <div class="card">
                        <div class="card-body">
                            <div class="card-img" style="margin: auto;">
                                <img src="<?=base_url();?>assets/img/4.jpg" height="230" width="230">
                            </div>
                            <div class="mt-3">
                            <h6 class="text-center"><a href="#">KOPI UNNIE</a></h6>
                            </div>
                        </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card">
                        <div class="card-body">
                            <div class="card-img" style="margin: auto;">
                                <img src="<?=base_url();?>assets/img/6.jpg" height="230" width="230">
                            </div>
                            <div class="mt-3">
                            <h6 class="text-center"><a href="#">SPRING DAY</a></h6>
                            </div>
                        </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card">
                        <div class="card-body">
                            <div class="card-img" style="margin: auto;">
                                <img src="<?=base_url();?>assets/img/8.jpg" height="230" width="230">
                            </div>
                            <div class="mt-3">
                            <h6 class="text-center"><a href="#">KOPI AHJJUSI</a></h6>
                            </div>
                        </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="card">
                        <div class="card-body">
                        <div class="card-img" style="margin: auto;">
                                <img src="<?=base_url();?>assets/img/9.jpg" height="230" width="230">
                            </div>
                            <div class="mt-3">
                            <h6 class="text-center"><a href="#">TTEOKPOKI</a></h6>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                    </div>
                    </div>

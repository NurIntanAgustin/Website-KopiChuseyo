<div class="card">
<div class="card-header bg-white">
	<h1 class="h3 text-gray-800"><?= $title_page ?? $title ?></h1>
</div>
<div class="mt-3">
  <?php foreach ($events_list as $list): ?>
    <div class="col-sm-12 col-lg-12">
    <div class="card mb-3" data-id="<?= $list['id_event'] ?>" style="margin: auto;">
        <div class="row">
            <div class="col-md-2">
                <div style="height: 150px; width: 150px;">
                <img src="<?= base_url()."assets/img/${list['gambar_event']}" ?>" class="img-fluid rounded-start" alt="Card image cap">
                </div>
            </div>
            <div class="col-md-8">
            <div class="card-body text-left">
                <div class="mt-4">
                <h5 class="card-title"><a href="<?= base_url();?>user/detail_events_page"><?= $list['nama_event'] ?></a></h5>
                <p class="card-text"><?= date("d F Y",strtotime($list['tanggal_event'])) ?></p>
                </div>
            </div>
            </div>
        </div>
    </div>
    </div>
  <?php endforeach ?>
</div>
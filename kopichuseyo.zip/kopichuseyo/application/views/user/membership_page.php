<div class="card">
<div class="card-header bg-white">
	<h1 class="h3 text-gray-800"><?= $title_page ?? $title ?></h1>
</div>
<div class="row mt-4" style="margin-left: 12rem;">
	<div class="offset-2 col-8">
		<div class="card bg-warning"  style="width: 470px;">
			<div class="card-header bg-warning">
				<div class="d-flex justify-content-between" style="width: 70%">
					<img src="<?= base_url()."assets/img/kopcus.png" ?>" height="45" width="60">
					<h4 class="align-self-center">
						<strong><?= strtoupper("member card") ?></strong>
					</h4>
				</div>
			</div>
			<div class="card-body">
				<h5 class="card-title"><?= $member_details['nama_member'] ?></h5>
				<p class="card-text"><?= date("d F Y",strtotime($member_details['tgl_lahir'])) ?></p>
				<br>
				<div class="d-flex">
					<div class="d-flex flex-column mr-auto">
						<p class="card-text text-left">
							<?= strtoupper("Silver") ?>
						</p>
						<p class="text-left">
							<strong>Level 2</strong>
						</p>
					</div>

					<div class="d-flex flex-column">
						<p class="card-text text-right">
							<?= strtoupper("poin saat ini") ?>
						</p>
						<p class="text-right">
							<strong>2000 PT</strong>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<ul class="nav nav-pills nav-fill mt-5">
	<li class="nav-item">
		<a class="nav-link active" id="pills-pencapaian-tab" data-toggle="pill" href="#pills-pencapaian" role="tab" aria-controls="pills-pencapaian" aria-selected="true">Pencapaian Kamu</a>
	</li>
	<li class="nav-item">
		<a class="nav-link" id="pills-keuntungan-tab" data-toggle="pill" href="#pills-keuntungan" role="tab" aria-controls="pills-keuntungan" aria-selected="false">Keuntungan Member</a>
	</li>
</ul>
<div class="tab-content mt-4" id="pills-tabContent">
	<div class="tab-pane fade show active" id="pills-pencapaian" role="tabpanel" aria-labelledby="pills-pencapaian-tab">
	<div class="mt-5 mb-5" style="padding: 20px 20px 20px 20px;">
		<label>
			Progress kamu selama ini
		</label>
		<div class="progress" style="height: 30px; border-radius: 0.8rem">
			<div class="progress-bar progress-bar-striped bg-warning" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">75%</div>
		</div>
		<p class="mt-3">
			kumpulkan lebih banyak keuntungan dengan naik level
		</p>
	</div>

	</div>
</div>
</div>
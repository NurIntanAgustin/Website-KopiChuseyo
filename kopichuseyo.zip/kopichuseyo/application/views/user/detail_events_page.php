<div class="card">
<div class="card-header bg-white">
	<h1 class="h3 text-gray-800"><?= $title_page ?? $title ?></h1>
</div>
                    <div class="card-body">
                        <div class="mt-3 text-center">
                        <img src="<?=base_url();?>assets/img/3.png" height="230" width="230"class="img-fluid rounded-start" alt="...">
                        </div>
                        <div class="mt-4 text-center">
                        <h5>VINCENZO CUPSLEEVE EVENT</h5>
                        </div>
                        <div class="mt-3">
                        <div class="card text-center">
                        <div class="card-header">
                            <ul class="nav nav-tabs card-header-tabs">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="true" href="<?=base_url();?>user/detail_events_page">Tentang</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" aria-current="true" href="<?=base_url();?>user/detail_events_page1">Cara Mendapatkan</a>
                            </li>
                            </ul>
                        </div>
                        <div class="card-body mt-3 text-left">
                            <p class="card-text">Vincenzo Cupsleeve Event merupakan event yang diadakan untuk memeriahkan
                                tayangnya drama Vincenzo
                            <br></br>
                            </p>
                            <p class="card-text">Apa yang akan kamu dapatkan?
                            </p>
                            <ul>
                                <li>Cupsleeve</li>
                                <li>3 Photocard</li>
                                <li>Handbanner</li>
                                <li>Stiker A5</li>
                                <li>2 Polaroid</li>
                            </ul>
                            <br></br>
                            <p class="card-text">Event By @keydrama.project on Instagram
                            </p>
                 
                        </div>
                        </div>
                        </div>
                    </div>
                    </div>
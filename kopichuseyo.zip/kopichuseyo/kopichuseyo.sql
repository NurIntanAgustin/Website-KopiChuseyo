-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 02 Agu 2021 pada 12.24
-- Versi server: 10.4.18-MariaDB
-- Versi PHP: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kopichuseyo`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `event`
--

CREATE TABLE `event` (
  `id_event` int(5) NOT NULL,
  `nama_event` varchar(50) NOT NULL,
  `tanggal_event` date NOT NULL,
  `penyelenggara` varchar(30) NOT NULL,
  `tentang` text NOT NULL,
  `cara_mendapatkan` text NOT NULL,
  `gambar_event` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `event`
--

INSERT INTO `event` (`id_event`, `nama_event`, `tanggal_event`, `penyelenggara`, `tentang`, `cara_mendapatkan`, `gambar_event`) VALUES
(1, 'VINCENZO CUPSLEEVE EVENT', '2021-08-10', '', 'Vincenzo Cupsleeve Event ini merupakan event yang diadakan untuk merayakan episode terakhir drama Vincenzo\r\n\r\n\r\nApa yang kamu dapatkan?\r\n1. Cupsleeve\r\n2. 2 Photocard\r\n3. 3 Polaroid\r\n4. Stiker A5\r\n5. Mini Handbanner', '1. Lakukan pemesanan di Kopi Chuseyo selain air mineral\r\n2. Tukarkan struk pemesanan kepada salah satu Admin kami yang ada di Stand\r\n3. Lakukan pembayaran Rp 5000/bundling', '3.png'),
(2, 'K-FOOD FOR THE WEEK', '2021-08-19', '@kopichuseyo.id', 'k-food for the week', 'k-food for the week', '1.jpg'),
(7, 'NCT ANNIVERSARY CUPSLEEVE EVENT', '2021-08-19', '@NCTZEN.CRB', 'nct', 'nct', '2.jpg'),
(8, 'HWANG INYOUP BIRTHDAY EVENT', '2021-08-21', '@keydrama.project', 'hiy', 'hiy', '4.png\r\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(5) NOT NULL,
  `nama_kategori` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'makanan'),
(2, 'minuman');

-- --------------------------------------------------------

--
-- Struktur dari tabel `member`
--

CREATE TABLE `member` (
  `id_member` int(5) NOT NULL,
  `nama_member` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `no_hp` varchar(13) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `member`
--

INSERT INTO `member` (`id_member`, `nama_member`, `tgl_lahir`, `jenis_kelamin`, `no_hp`, `email`) VALUES
(3, 'Lee Do Hyun', '1995-04-12', 'pria', '08572193506', 'dohyun@gmail.com'),
(4, 'karina', '2000-03-08', 'wanita', '08572193506', 'karina@gmail.com'),
(5, 'Intan', '2000-08-12', 'wanita', '085760603002', 'intan@gmail.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `menu`
--

CREATE TABLE `menu` (
  `id_menu` int(5) NOT NULL,
  `nama_menu` varchar(20) NOT NULL,
  `harga_menu` int(20) NOT NULL,
  `gambar_menu` varchar(200) NOT NULL,
  `id_kategori` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `menu`
--

INSERT INTO `menu` (`id_menu`, `nama_menu`, `harga_menu`, `gambar_menu`, `id_kategori`) VALUES
(5, 'Blue Flame', 24000, 'blue_flame.jpg', 2),
(6, 'Red Flavor', 22000, 'red_flavor.jpg', 2),
(7, 'White Regal', 22000, 'white_regal.jpg', 2),
(8, 'Banana Uyu', 24000, 'banana_uyu.jpg', 2),
(9, 'Spring Day', 20000, 'spring_day.jpg', 2),
(10, 'Kopi Unnie', 19000, 'kopi_unnie.jpg', 2),
(11, 'Brown Sugar', 21000, 'brown_sugar.jpg', 2),
(12, 'Caramel Mc', 25500, 'caramel_mc.jpg', 2),
(13, 'Dalgona Coffe', 24000, 'dalgona.jpg', 2),
(14, 'Kopi Oppa', 19000, 'kopi_unnie.jpg', 2),
(16, 'Bulgogi', 38000, 'bulgogi.jpg', 1),
(17, 'Ramyeon', 32000, 'ramyeon.jpg', 1),
(18, 'Mollayo', 40000, 'mollayo.jpg', 1),
(19, 'Tteokbokki', 30000, 'tteokbokki.jpg', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_bayar` int(5) NOT NULL,
  `nama_metode` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pembayaran`
--

INSERT INTO `pembayaran` (`id_bayar`, `nama_metode`) VALUES
(1, 'Tunai'),
(2, 'OVO'),
(3, 'Dana');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengiriman`
--

CREATE TABLE `pengiriman` (
  `id_pengiriman` int(8) NOT NULL,
  `id_pesanan` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesanan`
--

CREATE TABLE `pesanan` (
  `id_pesanan` int(8) NOT NULL,
  `id_user` int(5) NOT NULL,
  `id_shipment` int(3) NOT NULL,
  `id_menu` varchar(5) NOT NULL,
  `receipt_number` varchar(35) NOT NULL,
  `total_item` int(11) NOT NULL DEFAULT 1,
  `total_harga` int(20) NOT NULL,
  `alamat` text NOT NULL,
  `keterangan` text NOT NULL,
  `id_bayar` int(5) NOT NULL,
  `receipt_created_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pesanan`
--

INSERT INTO `pesanan` (`id_pesanan`, `id_user`, `id_shipment`, `id_menu`, `receipt_number`, `total_item`, `total_harga`, `alamat`, `keterangan`, `id_bayar`, `receipt_created_date`) VALUES
(26, 2, 2, '2', 'REC/20210801/090228b1e183fa065915', 3, 20000, '', '', 3, '2021-08-01 23:54:44'),
(27, 2, 2, '1', 'REC/20210801/090228b1e183fa065915', 1, 12000, '', '', 3, '2021-08-01 23:54:44'),
(28, 2, 3, '2', 'REC/20210802/50ade5a030fd552d15ef', 1, 5000, '', '', 1, '2021-08-02 01:59:58'),
(29, 2, 3, '5', 'REC/20210802/50ade5a030fd552d15ef', 1, 24000, '', '', 1, '2021-08-02 01:59:58'),
(30, 2, 3, '7', 'REC/20210802/50ade5a030fd552d15ef', 1, 22000, '', '', 1, '2021-08-02 01:59:58'),
(31, 8, 2, '5', 'REC/20210802/03a1de7c8313535ce9f3', 1, 24000, '', '', 3, '2021-08-02 13:34:50'),
(32, 8, 2, '7', 'REC/20210802/03a1de7c8313535ce9f3', 2, 44000, '', '', 3, '2021-08-02 13:34:50'),
(33, 8, 0, '5', '', 1, 24000, '', '', 0, '2021-08-02 16:10:14'),
(34, 8, 0, '6', '', 1, 22000, '', '', 0, '2021-08-02 16:10:15'),
(35, 8, 0, '7', '', 2, 44000, '', '', 0, '2021-08-02 16:10:17');

-- --------------------------------------------------------

--
-- Struktur dari tabel `reservasi`
--

CREATE TABLE `reservasi` (
  `id_rsv` int(5) NOT NULL,
  `tgl_rsv` date NOT NULL,
  `id_user` int(11) NOT NULL,
  `kode_reservasi` varchar(13) NOT NULL,
  `jumlah_org` int(10) NOT NULL,
  `no_meja` int(5) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `no_hp` varchar(13) NOT NULL,
  `email` varchar(50) NOT NULL,
  `id_bayar` int(5) NOT NULL,
  `reservasi_created_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `reservasi`
--

INSERT INTO `reservasi` (`id_rsv`, `tgl_rsv`, `id_user`, `kode_reservasi`, `jumlah_org`, `no_meja`, `nama`, `no_hp`, `email`, `id_bayar`, `reservasi_created_date`) VALUES
(2, '2021-08-15', 2, '3316536700834', 8, 14, 'Lee Do Hyun', '890412', 'dohyun@gmail.com', 2, '2021-08-01 19:30:56'),
(3, '2021-08-19', 2, '3866848057481', 9, 11, 'Lee Do Hyun', '081321338839', 'dohyun@gmail.com', 2, '2021-08-01 22:25:55'),
(4, '2021-08-10', 8, '4560451982674', 4, 8, 'Intan', '085760603002', 'intan@gmail.com', 3, '2021-08-02 12:33:20');

-- --------------------------------------------------------

--
-- Struktur dari tabel `shipment`
--

CREATE TABLE `shipment` (
  `id_shipment` int(5) NOT NULL,
  `nama_shipment` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `shipment`
--

INSERT INTO `shipment` (`id_shipment`, `nama_shipment`) VALUES
(1, 'Pick Up'),
(2, 'Dine In'),
(3, 'Delivery');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `image` text NOT NULL,
  `role_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `nama`, `email`, `password`, `image`, `role_id`) VALUES
(1, 'Zaki Santoso', 'zakisans@gmail.com', '$2y$10$OvJaNrUjPSewsIEPNLka7uXNgIVlu1kHMoRw01IH6voi2Wufj0oMe', 'default.jpg', 2),
(2, 'Lee Do Hyun', 'dohyun@gmail.com', '$2y$10$1rnpHY905mXuafpWX0cW1OAB0p4gRhMmSmgiDBtOTDYIPd8C3tzj6', 'default.jpg', 2),
(3, 'Aulia', 'aulia@gmail.com', '$2y$10$ICkBukHNN5IAKSTvoc4WO.C1J2CkTFcoodlB5Ak1G0FVYwcN1Y3AS', 'default.jpg', 1),
(5, 'karina', 'karina@gmail.com', '$2y$10$HDfiSx1oWWtEmTpNKt/SYeT79Teb0hG8/xXKI6./SbMWtDQGemoE.', 'default.jpg', 2),
(6, 'Winter', 'winter@gmail.com', '$2y$10$ZqeemUxCscM3xWMvXWrpkeyKZRVskkpIJhIux83lnNea/eb9qTG.e', 'default.jpg', 2),
(7, 'Karina', 'karina@gmail.com', '$2y$10$iFepAVpOOQwYBjhYdLDVSO4.Vxkl4agp7jraP.LhXq81snR.6fMcm', 'default.jpg', 2),
(8, 'Intan', 'intan@gmail.com', '$2y$10$yFEA2vAQr2dUFRteUfokduuJ4p07JA0XQVByWs76MVGXiZlLpk4m.', 'default.jpg', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_role`
--

CREATE TABLE `user_role` (
  `role_id` int(11) NOT NULL,
  `role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user_role`
--

INSERT INTO `user_role` (`role_id`, `role`) VALUES
(1, 'Admin'),
(2, 'Member');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id_event`);

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id_member`);

--
-- Indeks untuk tabel `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id_menu`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indeks untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_bayar`);

--
-- Indeks untuk tabel `pengiriman`
--
ALTER TABLE `pengiriman`
  ADD PRIMARY KEY (`id_pengiriman`),
  ADD KEY `id_pesanan` (`id_pesanan`);

--
-- Indeks untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`id_pesanan`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_menu` (`id_menu`),
  ADD KEY `id_bayar` (`id_bayar`);

--
-- Indeks untuk tabel `reservasi`
--
ALTER TABLE `reservasi`
  ADD PRIMARY KEY (`id_rsv`),
  ADD KEY `id_bayar` (`id_bayar`);

--
-- Indeks untuk tabel `shipment`
--
ALTER TABLE `shipment`
  ADD PRIMARY KEY (`id_shipment`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- Indeks untuk tabel `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`role_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `event`
--
ALTER TABLE `event`
  MODIFY `id_event` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `member`
--
ALTER TABLE `member`
  MODIFY `id_member` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `menu`
--
ALTER TABLE `menu`
  MODIFY `id_menu` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_bayar` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  MODIFY `id_pesanan` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT untuk tabel `reservasi`
--
ALTER TABLE `reservasi`
  MODIFY `id_rsv` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `shipment`
--
ALTER TABLE `shipment`
  MODIFY `id_shipment` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `user_role`
--
ALTER TABLE `user_role`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
